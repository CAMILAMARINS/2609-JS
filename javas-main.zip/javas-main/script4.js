let num
let result = 0

    num = Number(prompt("Digite um número:"))
    soma = num-1

        while(soma!=0) {
            num = num*soma
             soma--

            console.log(result)
            
    } alert(num)