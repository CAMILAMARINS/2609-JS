let num, adicao=0

    num = Number (prompt("Digite um número:"))

        while(num>0) {
             adicao = num+adicao

            console.log(adicao)
            num = Number (prompt("Digite um número:"))
    }