let numero
let variavel = 0

    numero = Number (prompt("Digite um número:"))

        while(variavel >= 0 && variavel <= 10) {
             multiplicacao = numero*variavel

            console.log(multiplicacao)

            variavel++
    }